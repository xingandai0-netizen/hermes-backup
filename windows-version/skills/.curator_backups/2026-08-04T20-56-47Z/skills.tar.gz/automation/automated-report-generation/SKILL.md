---
name: automated-report-generation
description: Generate automated reports (JSON + HTML) via web scraping when terminal/execute_code are blocked. Covers cron-mode fallback, large-file chunking, multi-format output, pointer management, and run logging.
triggers:
  - automated report generation
  - cron job report
  - tech trend report
  - GitHub trending report
  - scheduled report
  - web scrape and generate report
  - terminal blocked fallback
---

# Automated Report Generation

Generate structured reports by scraping web data when Python scripts or terminal commands are unavailable (e.g. cron mode security policy blocking `terminal` and `execute_code`).

## When to Use

- Scheduled cron jobs that need to generate daily/weekly reports
- Python scripts exist but can't execute (security policy, missing deps, etc.)
- Need to produce JSON data + HTML report + logs from web sources
- Large output files that risk stream timeouts

## Workflow

### Step 1: Collect Data via Web Tools

```
web_search(query="...", limit=5)  # Discovery
web_extract(urls=[...])           # Detailed content
```

- Use `web_search` first to find data sources
- Use `web_extract` on structured pages (GitHub trending, dashboards, APIs)
- Extract into structured Python dicts/lists in your head

### Step 2: Generate JSON Data File

Write structured data as JSON. Keep the file **under 5KB** — if larger, split into a main file + supplementary files.

```
write_file(path="reports/trend_data_YYYYMMDD_HHMMSS.json", content=...)
```

### Step 3: Generate HTML Report (CHUNKED)

**⚠️ CRITICAL: HTML reports must be written in chunks to avoid stream timeouts.**

1. **Write the HTML shell** (head, styles, first section) via `write_file`. Keep under ~5KB.
2. **Patch in remaining sections** via `patch(mode='replace')` — replace placeholder comments like `<!-- PART 2 CONTINUES -->` with actual content.
3. Each patch call should add **one section** (e.g., Top 10 repos, language distribution, insights).

Example:
```python
# Step 3a: Write shell with first 5 repos
write_file(path="report.html", content=html_shell_with_placeholder)

# Step 3b: Patch in remaining repos + sections
patch(mode='replace', path="report.html",
      old_string="<!-- PART 2 CONTINUES -->",
      new_string=remaining_repos_html + insights_html + footer_html)
```

### Step 4: Update Pointer Files

Update "latest" pointer files so they always point to today's report:

```
write_file(path="reports/latest_data.json", content=minimal_json_summary)
write_file(path="reports/latest_report.html", content=redirect_html)
```

The redirect HTML:
```html
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Latest</title></head>
<body>
<script>window.location.href='report_YYYYMMDD.html';</script>
<p>Redirecting to <a href="report_YYYYMMDD.html">today's report</a></p>
</body></html>
```

### Step 5: Update Logs

Update **all** of these:

| Log File | Format | Update Method |
|----------|--------|---------------|
| `data/email_log.csv` | CSV rows | `patch` append after last row |
| `data/system_run.log` | Markdown entries | `patch` append after last entry |
| `data/daily_status_report.md` | Full status report | `write_file` overwrite |
| `logs/daily_run.jsonl` | JSONL entries | `patch` append after last entry |

**⚠️ For `system_run.log`**: The string `- Status: ✅ SUCCESS` appears multiple times. Use a longer unique context string (include the preceding `Method:` line) to avoid ambiguity in patch.

### Step 6: Simulate Email Delivery

If no real SMTP is configured, log emails as "simulated":

```csv
2026-07-24T09:00:00,user@example.com,Report Subject,sent,simulated
```

## Pitfalls

1. **Stream timeout on large files**: Never write HTML reports >5KB in a single `write_file`. Always chunk.
2. **Patch ambiguity**: When appending to logs, use enough unique context to avoid matching multiple locations.
3. **Pointer file format**: `latest_report.html` should be a simple redirect, not the full report.
4. **Cron mode**: `terminal` and `execute_code` are blocked in cron jobs (tirith security). Always use `web_search` + `web_extract` + `write_file` + `patch`.
5. **JSON data size**: Keep `latest_data.json` minimal (~1KB). Full data goes in the timestamped file.

## File Structure

```
reports/
  trend_data_YYYYMMDD_HHMMSS.json    # Full data
  trend_report_YYYYMMDD_HHMMSS.html  # Full HTML report
  latest_data.json                    # Pointer (minimal)
  latest_report.html                  # Redirect pointer
data/
  daily_status_report.md             # Overwritten each run
  email_log.csv                      # Appended each run
  system_run.log                     # Appended each run
logs/
  daily_run.jsonl                    # Appended each run
```
