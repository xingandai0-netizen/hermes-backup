# Cron Mode Constraints

## Security Policy

When running as a Hermes scheduled cron job, the following tools are **blocked** by tirith security:
- `terminal` — all shell commands (even `pwd`)
- `execute_code` — Python execution with subprocess

These return `exit_code: -1` with `status: "pending_approval"` that never resolves (no user present).

## Working Tools in Cron Mode

These tools work normally:
- `web_search` — search engine queries
- `web_extract` — fetch and parse web pages
- `write_file` — create/overwrite files
- `patch` — find-and-replace edits
- `read_file` — read existing files
- `search_files` — find files by name/pattern

## Email Simulation Pattern

Without SMTP access (blocked terminal), simulate email delivery by:
1. Reading `data/subscribers.csv` for active subscribers
2. Generating email content (subject, HTML, text) from report data
3. Appending rows to `data/email_log.csv` with `mode=simulated`
4. Each row: `timestamp,email,subject,status,mode`

## Log Rotation

Logs are append-only. Files grow over time. Current log sizes after ~2 months of daily runs:
- `email_log.csv`: ~30 rows
- `system_run.log`: ~40 lines  
- `daily_run.jsonl`: ~80 lines

No rotation implemented yet. Consider periodic cleanup if files exceed 100KB.

## Past Run History

Runs have been successful since at least 2026-06-24 using the fallback pattern.
Last verified: 2026-07-24.

## Cron Job Config Issue

The cron job references a skill named "GitHub Trend Monitor" which does not exist. It gets skipped every run with:
```
[IMPORTANT: The following skill(s) were listed for this job but could not be found and were skipped: GitHub Trend Monitor]
```
This skill (`automated-report-generation`) should be used instead. The cron config should be updated to reference `automated-report-generation` instead of `GitHub Trend Monitor`.
