# Web Search Aggregation Fallback (2026-06-13)

When ALL direct data access fails (browser_navigate, web_extract, execute_code, terminal), `web_search` aggregation can still produce a partial but useful report.

## When to Use

- `browser_navigate` fails (agent-browser not installed)
- `web_extract` fails (DuckDuckGo backend = search-only)
- `execute_code` blocked (approvals.cron_mode)
- `terminal` blocked (tirith security scanner)

## Method

Run 3-5 targeted web_search queries and synthesize results:

### Query Strategy

1. **Direct trending query**: `"github trending" "stars today" June 2026 repository list`
2. **Category-specific**: `github trending repositories June 2026 stars gained today AI agent MCP`
3. **Date-specific**: `github trending repositories list June 2026 stars language description`
4. **Third-party trackers**: `site:github.com/trending stars today 2026`
5. **Digest sites**: `"github trending" "June 2026" repository stars list top 10`

### Data Extraction from Search Results

Search result descriptions often contain:
- Repository names (from github.com URLs)
- Star counts (from snippets like "3,558 stars today (34.2k total)")
- Languages (from GitHub metadata in descriptions)
- Descriptions (from repo descriptions in snippets)
- Category info (from third-party trackers like trendshift.io, orangebot.ai)

### Useful Third-Party Sources (ranked by snippet quality, updated 2026-06-14)

**Tier 1 — Best for search snippet extraction** (structured data visible without page visit):
- `wangchujiang.com/github-rank/trending.html` — cached daily, shows "stars today" per repo in snippet. Monthly: `trending-monthly.html`
- `orangebot.ai/github-trending-today` — hourly refresh, confirmed "1 day ago" freshness (2026-06-14)

**Tier 2 — Good for category/theme data**:
- `trendshift.io` — daily momentum with categories (`/monthly`, `/topics`)
- `ossinsight.io/trending/ai` — AI-specific trending, 10B+ events
- `shareuhack.com/en/posts/github-trending-weekly-*` — weekly digests with analysis
- `repofomo.com` — FomoRank blended momentum (7/30/60 day)

**Tier 3 — Useful but less structured snippets**:
- `gitstar.space` — daily/weekly/monthly rankings
- `www.ghtrending.com/trending` — momentum/freshness ranking
- `gitgazette.com/trending` — GitHub trending repos

**Pitfall**: GitHub's own trending page (`github.com/trending`) snippets often contain NO useful data — just "GitHub is where people build software." Optimize queries toward third-party trackers instead.

## Limitations

- Data is aggregated from search snippets, not direct page scraping
- Star counts may be from different dates (not same-day)
- Some repos may be missing or have stale data
- Cannot get "stars today" velocity precisely — only weekly/monthly approximations
- Quality depends on what search engines index and cache

## Output Quality

Produces ~70-80% coverage compared to direct GitHub Trending scrape. Good enough for trend identification and Hermes integration analysis, but not suitable for precise daily star velocity tracking.

## Pattern: Multi-Source Synthesis

```
1. Run 3-5 web_search queries with different angles
2. Extract repo names, stars, languages from all result descriptions
3. Cross-reference: same repo appearing in multiple results = higher confidence
4. Use third-party tracker descriptions for category/theme data
5. Build JSON report in agent reasoning
6. Save via write_file(path="/Users/macpro/trending_repos.json", content=json_string)
```

## Verified

### 2026-06-13 (first run)
- 10 repos identified from aggregated search results
- 5 had precise star counts, 5 had approximate ranges
- Language distribution and keyword analysis completed
- Hermes integration opportunities identified for 8/10 repos
- Total report: 10.7KB JSON saved via write_file

### 2026-06-14 (second run)
- 12 repos identified (improvement: targeted third-party tracker queries)
- 7 Hermes opportunities (5 HIGH, 2 MEDIUM)
- Complete HTML + JSON + status report + email log + run log generated
- All 5 subscribers logged as "simulated" send
- Total execution: ~3 minutes, 10 write_file calls
- Key improvement: querying `wangchujiang.com` and `orangebot.ai` directly in search terms yielded richer snippets than generic "github trending" queries
