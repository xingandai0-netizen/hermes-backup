## MiMo（小米）— 官方定价（2026-05确认）

**API平台**: https://platform.xiaomimimo.com
**API基础URL**: https://token-plan-cn.xiaomimimo.com/v1 (OpenAI) / /anthropic (Anthropic)
**协议**: OpenAI + Anthropic 双协议
**计费模型**: Token Plan 预付费套餐制
**定价文档**: https://platform.xiaomimimo.com/static/docs/pricing.md
**llms.txt**: https://platform.xiaomimimo.com/llms.txt

### 国内定价（元/1M tokens, ≤256K上下文）

| 模型 | Input(Cache Hit) | Input(Cache Miss) | Output |
|------|:-:|:-:|:-:|
| mimo-v2.5-pro | ¥1.40 | ¥7.00 | ¥21.00 |
| mimo-v2-pro | ¥1.40 | ¥7.00 | ¥21.00 |
| mimo-v2.5 | ¥0.56 | ¥2.80 | ¥14.00 |
| mimo-v2-omni | ¥0.56 | ¥2.80 | ¥14.00 |
| mimo-v2-flash | ¥0.07 | ¥0.70 | ¥2.10 |
| mimo-v2-tts | 限时免费 | — | — |
| mimo-v2.5-tts | 限时免费 | — | — |
| mimo-v2.5-tts-voiceclone | 限时免费 | — | — |
| mimo-v2.5-tts-voicedesign | 限时免费 | — | — |

### 海外定价（$/1M tokens, ≤256K上下文）

| 模型 | Input(Cache Hit) | Input(Cache Miss) | Output |
|------|:-:|:-:|:-:|
| mimo-v2.5-pro / mimo-v2-pro | $0.20 | $1.00 | $3.00 |
| mimo-v2.5 | $0.08 | $0.40 | $2.00 |
| mimo-v2-omni | $0.08 | $0.40 | $2.00 |
| mimo-v2-flash | $0.01 | $0.10 | $0.30 |
| TTS全系 | 限时免费 | — | — |

### TTS计费说明
- TTS系列按token计费，**非按次收费**
- 当前全部限时免费(Limited-time free)
- 上下文: 8K, 最大输出: 8K, RPM: 100, TPM: 10M

### 网络搜索插件
- 国内: ¥25/1000次
- 海外: $5/1000次

### 获取方式
需要小米账号 → platform.xiaomimimo.com → Token Plan后台 → 购买套餐
