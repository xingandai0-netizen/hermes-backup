## Trending Page DOM Extraction via browser_console (verified 2026-05-16)

When the API endpoint returns "recently updated" repos (not truly trending),
use the GitHub Trending page directly with `browser_console` DOM queries
for structured JSON extraction. This is MORE reliable than parsing the
accessibility tree snapshot manually.

### Why Use This Over browser_snapshot

| Method | Pros | Cons |
|--------|------|------|
| `browser_snapshot` | Shows full page structure | Requires manual text parsing from accessibility tree |
| `browser_console` DOM | Returns structured JSON directly | Requires JS expression |

**Recommendation**: Use `browser_console` DOM extraction as PRIMARY for trending page data.
Use `browser_snapshot` only as fallback when `browser_console` isn't available.

### Complete Working Pattern (verified 2026-05-16)

```python
# Step 1: Navigate to trending page
browser_navigate(url="https://github.com/trending?since=daily")

# Step 2: Extract structured data via DOM queries
browser_console(expression="""
const articles = document.querySelectorAll('article');
const repos = [];
articles.forEach(a => {
  const heading = a.querySelector('h2 a');
  const desc = a.querySelector('p');
  const starsEl = a.querySelector('a[href*="stargazers"]');
  const forksEl = a.querySelector('a[href*="forks"]');
  const todayEl = a.querySelector('.float-sm-right');
  
  if (heading) {
    const name = heading.textContent.trim();
    // Language detection: check known language names in span elements
    const langSpan = a.querySelectorAll('span');
    let lang = 'Unknown';
    langSpan.forEach(s => {
      const t = s.textContent.trim();
      if (['Python','Rust','Go','TypeScript','JavaScript','C++','C#',
           'Java','Kotlin','Swift','Shell','Ruby','Lua','PHP',
           'Emacs Lisp','Dart'].includes(t)) {
        lang = t;
      }
    });
    
    const starsText = starsEl ? starsEl.textContent.trim().replace(/[^0-9,]/g, '') : '0';
    const forksText = forksEl ? forksEl.textContent.trim().replace(/[^0-9,]/g, '') : '0';
    const todayText = todayEl ? todayEl.textContent.trim() : '';
    
    repos.push({
      name: name,
      desc: desc ? desc.textContent.trim().substring(0, 120) : '',
      lang: lang,
      stars: starsText,
      forks: forksText,
      stars_today: todayText
    });
  }
});
JSON.stringify(repos);
""")
```

### Key Details

1. **Name cleanup**: `heading.textContent.trim()` may include newlines/whitespace from
   the HTML structure. Clean with `.replace(/\\n/g, '').replace(/\\s+/g, ' ').trim()`
   or handle downstream.

2. **Language detection**: No single selector reliably captures language. The pattern
   checks all `<span>` children against a known-language whitelist. Update the whitelist
   as new languages appear in trending.

3. **Star/fork text format**: Returns `" 9,375"` with leading space and commas.
   The regex `/[^0-9,]/g` strips non-numeric characters, leaving `"9,375"`.

4. **Stars today text**: Returns like `" 1,271 stars today"` — needs post-processing
   to extract the number if you want it as an integer.

5. **Sponsored repos**: May include "Sponsor" link — these are real trending repos
   that also have sponsor buttons. No need to filter them out.

### Combined Approach: API + Trending Page

For maximum coverage, fetch BOTH data sources:
- **Trending page** → what's HOT right now (velocity-based)
- **Search API** (`sort=updated`) → recently committed code (time-based)

The trending page data is typically more interesting for trend analysis because
it reflects momentum, not just activity. Use the API data as supplementary context.

### Post-Processing: Parse Stars/Today Numbers

```python
# In the analysis code after extraction:
def parse_number(text):
    """Parse '9,375' or '1,271 stars today' to int."""
    num_str = ''.join(c for c in text if c.isdigit() or c == ',')
    return int(num_str.replace(',', '')) if num_str else 0
```
