"""
GitHub Trend Monitor — Complete Working Example
Generated from 2026-05-12 successful cron execution.

Usage: paste into execute_code tool in Hermes.
This is the proven pattern that works in cron job context.
"""

import json, urllib.request, urllib.error
from datetime import datetime
from collections import Counter

# ── Step 1: Fetch ──────────────────────────────────────────────
url = "https://api.github.com/search/repositories?q=stars:%3E500&sort=updated&order=desc&per_page=10"
headers = {
    "User-Agent": "Hermes-Agent/1.0",
    "Accept": "application/vnd.github.v3+json"
}
req = urllib.request.Request(url, headers=headers)

try:
    resp = urllib.request.urlopen(req, timeout=15)
    raw = resp.read().decode("utf-8")
    data = json.loads(raw)
except urllib.error.HTTPError as e:
    print(f"HTTP Error {e.code}: {e.reason}")
    print(e.read().decode()[:500])
    raise SystemExit(1)

# ── Step 2: Parse ──────────────────────────────────────────────
repos = []
for r in data.get("items", []):
    repos.append({
        "name": r["full_name"],
        "description": (r.get("description") or "")[:200],
        "stars": r["stargazers_count"],
        "language": r.get("language") or "N/A",
        "updated_at": r["updated_at"],
        "topics": r.get("topics", []),
        "url": r["html_url"],
        "forks": r["forks_count"],
        "open_issues": r["open_issues_count"],
        "license": (r.get("license") or {}).get("spdx_id", "N/A"),
        "created_at": r["created_at"],
    })

# ── Step 3: Analyze ───────────────────────────────────────────
lang_counter = Counter(r["language"] for r in repos if r["language"] != "N/A")

kw_list = ["ai", "llm", "agent", "mcp", "api", "cli", "automation", "tool",
           "framework", "model", "inference", "deploy", "rust", "python",
           "typescript", "server", "security", "ml", "data"]
kw_counter = Counter()
for r in repos:
    text = f"{r['description'].lower()} {r['name'].lower()} {' '.join(r['topics'])}"
    for kw in kw_list:
        if kw in text:
            kw_counter[kw] += 1

# ── Step 4: Integration Opportunities ─────────────────────────
mcp_related, agent_related, api_cli_related = [], [], []
for r in repos:
    text = f"{r['description'].lower()} {r['name'].lower()} {' '.join(r['topics'])}"
    if any(k in text for k in ["mcp", "model-context-protocol"]):
        mcp_related.append(r["name"])
    if any(k in text for k in ["agent", "automation", "workflow", "orchestrat"]):
        agent_related.append(r["name"])
    if any(k in text for k in ["api", "sdk", "cli", "tool", "server"]):
        api_cli_related.append(r["name"])

# ── Step 5: Build & Save Output ───────────────────────────────
from pathlib import Path
output_path = Path("/Users/macpro/reports")
output_path.mkdir(parents=True, exist_ok=True)

timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M")

report_json = {
    "fetch_time": datetime.utcnow().isoformat() + "Z",
    "total_count": data.get("total_count", 0),
    "repos": repos,
    "analysis": {
        "language_distribution": dict(lang_counter),
        "keyword_frequency": dict(kw_counter.most_common(20)),
        "integration_opportunities": {
            "mcp_related": mcp_related,
            "agent_automation": agent_related,
            "api_cli_tools": api_cli_related,
        },
    },
}

json_path = output_path / f"trend_data_{timestamp}.json"
with open(json_path, "w", encoding="utf-8") as f:
    json.dump(report_json, f, indent=2, ensure_ascii=False)

# Also save as latest
latest_path = output_path / "latest_data.json"
with open(latest_path, "w", encoding="utf-8") as f:
    json.dump(report_json, f, indent=2, ensure_ascii=False)

# ── Step 6: Generate Bilingual Report ─────────────────────────
report = []
report.append("=" * 65)
report.append("📊 GitHub 趋势仓库 Top 10 分析报告")
report.append(f"🕐 时间: {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}")
report.append("=" * 65)
report.append("")

report.append("## 📦 Top 10 仓库概览\n")
for i, r in enumerate(repos, 1):
    report.append(f"{i:2d}. **{r['name']}** ⭐{r['stars']:,} | {r['language']} | 🍴{r['forks']:,}")
    desc = r["description"][:100] + "..." if len(r["description"]) > 100 else r["description"]
    report.append(f"    {desc}")
    report.append(f"    🔗 {r['url']}")
    if r["topics"]:
        report.append(f"    🏷️  {', '.join(r['topics'][:5])}")
    report.append("")

report.append("## 📈 语言分布\n")
for lang, count in lang_counter.most_common():
    bar = "█" * (count * 4)
    report.append(f"  {lang:15s} {bar} ({count})")
report.append("")

report.append("## 🔑 关键词频率\n")
for kw, count in kw_counter.most_common(10):
    report.append(f"  {kw:15s} {'●' * count} ({count})")
report.append("")

report.append("## 🎯 Hermes 集成机会分析\n")
if mcp_related:
    report.append(f"### 🔌 MCP 相关 ({len(mcp_related)}):")
    for name in mcp_related:
        report.append(f"  - **{name}** → 可集成 MCP server/client")
    report.append("")
if agent_related:
    report.append(f"### 🤖 Agent/自动化 ({len(agent_related)}):")
    for name in agent_related:
        report.append(f"  - **{name}** → 可封装为 Hermes skill")
    report.append("")
if api_cli_related:
    report.append(f"### 🔧 API/CLI/工具 ({len(api_cli_related)}):")
    for name in api_cli_related:
        report.append(f"  - **{name}** → 可集成为 Hermes 工具")
    report.append("")

report.append("---")
report.append(f"📁 JSON: {json_path}")
report.append(f"📊 共分析 {len(repos)} 个仓库 | GitHub 总匹配: {data.get('total_count', 0):,}")

print("\n".join(report))
