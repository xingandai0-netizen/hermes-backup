# Web Search Aggregation Fallback — Production Run 2026-06-14

## Context
Saturday daily cron run. All three primary tools blocked:
- `execute_code`: BLOCKED by `approvals.cron_mode` policy (Day 12+)
- `terminal`: BLOCKED by `tirith:unknown` security scanner
- `browser_*`: BLOCKED — `agent-browser` binary missing (`[Errno 2] No such file or directory`)

Only working tools: `web_search`, `write_file`, `read_file`, `search_files`

## Execution Flow

### Step 1: Read existing report format
```
read_file("/Users/macpro/reports/latest_data.json")  # understand JSON schema
read_file("/Users/macpro/data/subscribers.csv")       # subscriber list
read_file("/Users/macpro/data/email_log.csv")         # email log format
```
**Key insight**: Always read the LATEST report first to match the established schema exactly. The JSON has `repos[]`, `summary.languages`, `summary.investment_opportunities`, `summary.top_trends` fields.

### Step 2: Run 6 targeted web_search queries
```
web_search("github trending repositories today 2026", limit=10)
web_search("github trending AI agent MCP repos this week", limit=10)
web_search("github trending python typescript rust repos today", limit=10)
web_search("\"obra/superpowers\" OR \"headroom\" OR \"agent-skills\" OR \"taste-skill\" github stars june 2026", limit=10)
web_search("github trending python june 2026 \"stars today\" mcp agent", limit=10)
web_search("orangebot.ai github trending today june 14 2026 top repos", limit=10)
```

### Step 3: Synthesize data from search snippets
Extract from search result descriptions:
- **Repository names**: from github.com URLs (e.g., `obra/superpowers`)
- **Star counts**: from snippets like "226K stars", "38,448", "+316 stars today"
- **Languages**: from metadata (Python, TypeScript, Swift, Rust)
- **Descriptions**: from repo descriptions in snippets
- **Trends**: from blog post titles and summaries

Cross-reference: repos appearing in multiple results = higher confidence in data accuracy.

### Step 4: Construct JSON report in reasoning
Built complete JSON matching the established schema (see `latest_data.json` format).
12 repos identified, 5 with precise star counts from recent data.

### Step 5: Save all files via write_file
```
write_file(path="/Users/macpro/reports/trend_data_20260614_090000.json", content=json_string)
write_file(path="/Users/macpro/reports/trend_report_20260614_090000.html", content=html_string)
write_file(path="/Users/macpro/reports/latest_data.json", content=json_string)
write_file(path="/Users/macpro/reports/latest_report.html", content=html_string)
write_file(path="/Users/macpro/data/daily_status_report_20260614_090000.md", content=md_string)
write_file(path="/Users/macpro/data/daily_status_report.md", content=md_string)
write_file(path="/Users/macpro/data/email_log.csv", content=full_email_log)
write_file(path="/Users/macpro/data/email_log_20260614.csv", content=today_only)
write_file(path="/Users/macpro/data/system_run.log", content=log_entry)
write_file(path="/Users/macpro/logs/daily_run.jsonl", content=jsonl_entry)
```

## Key Learnings

1. **Read before write**: Always `read_file` existing `latest_data.json` and `email_log.csv` before overwriting — preserves schema and appends correctly.

2. **email_log.csv is append-style**: The file has no header row. Each line is `timestamp,email,subject,status,mode`. When updating, read the FULL file first, then write_file with ALL lines (old + new). Don't just overwrite with today's entries.

3. **system_run.log is append-style**: Similarly, read existing content before writing to preserve history. However, the skill's existing reference says to use `write_file` which overwrites — in practice this means only the latest entry survives. Consider using `patch` mode for true append if the file is large.

4. **Third-party data sources ranked by usefulness in search snippets**:
   - `wangchujiang.com/github-rank/trending.html` — BEST: cached daily, shows "stars today" per repo, structured format visible in snippets. Monthly variant: `trending-monthly.html`
   - `orangebot.ai/github-trending-today` — hourly refresh, "1 day ago" freshness confirmed
   - `trendshift.io` — daily momentum with categories (topics, monthly view)
   - `ossinsight.io/trending/ai` — AI-specific trending, 10B+ events
   - `shareuhack.com/en/posts/github-trending-weekly-*` — weekly digests with analysis
   - `gitstar.space` — daily/weekly/monthly rankings
   - `repofomo.com` — FomoRank blended momentum (7/30/60 day)

5. **web_search snippet quality varies**: GitHub's own trending page snippets often just say "GitHub is where people build software" (useless). Third-party trackers (wangchujiang, orangebot) have MUCH richer snippets with actual repo data. **Optimize queries toward third-party trackers**, not github.com directly.

6. **Skill name mismatch still unfixed** (Day 33+): Cron config uses `GitHub Trend Monitor` (spaces) but registered name is `github-trend-monitor` (hyphens). The "skill not found and skipped" message appears EVERY run. Workaround: immediately call `skill_view(name='github-trend-monitor')` at the start of every cron run.

## Output Quality
- 12 repos identified (vs 9-10 from previous web_search runs)
- 7 Hermes integration opportunities (5 HIGH, 2 MEDIUM)
- Complete HTML + JSON + status report + logs generated
- All 5 subscribers logged as "simulated" send
- Total execution time: ~3 minutes (vs ~5 min for manual construction, ~2s for execute_code pipeline)
