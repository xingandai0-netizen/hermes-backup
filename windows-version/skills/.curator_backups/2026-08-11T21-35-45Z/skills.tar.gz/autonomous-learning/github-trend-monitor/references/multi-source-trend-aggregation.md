# Multi-Source Trend Data Aggregation (Verified 2026-06-30)

## Problem
GitHub Trending page is JavaScript-rendered and hard to scrape reliably.
Single web_search queries may miss repos or return stale data.

## Solution: Aggregate from 5+ curated sources

### Primary sources (ranked by reliability):
1. **orangebot.ai/github-trending-today** — Daily top 13-25, date-stamped, reliable
2. **gitgazette.com/trending** — Star counts, daily gains, descriptions
3. **github.attentionvc.ai/trending/repos** — Top 25 with today/7d tabs, topic tags
4. **startupcorners.com/digest** — Weekly digest with star deltas and analysis
5. **aitoolradar.io/blog** — Monthly deep-dive on rising repos with license info

### Search queries that work:
```
web_search("GitHub trending repositories today 2026 AI machine learning", limit=10)
web_search("GitHub trending repos open source this week stars rising", limit=10)
web_search("trending AI tools developer tools GitHub June 2026", limit=10)
```

### Data extraction pattern:
From each source, extract:
- Repo name (owner/name)
- Star count
- Daily/weekly gain
- Language
- One-line description
- Topic tags

### Deduplication:
Same repo may appear in multiple sources. Merge by repo name, keep highest star count.

### Cross-validation:
If 3+ sources agree on a repo trending, high confidence.
If only 1 source lists it, mark as "single-source" in report.

## Verified stats (2026-06-30 run):
- 5 search queries → 3 successful, 2 SSL failures (acceptable)
- 13 unique repos identified across sources
- Top repo (simplex-chat) confirmed by 3 independent sources
- Total processing: ~30 seconds

## When to use
- Daily/weekly trend report generation
- Any "what's trending on GitHub" analysis
- Investment opportunity scouting
- Competitive intelligence for tech companies
