# Cron Execution Notes — GitHub Trend Monitor

## Critical: Cron Job Execution Constraints

### What Gets Blocked
- `execute_code` — blocked by security policy in cron jobs
- `terminal` with python scripts (heredoc or file-based) — blocked by Tirith security scanning with `tirith:unknown` pattern
- `terminal` with `-c` flag — blocked by Tirith even for simple commands
- Any terminal command that runs arbitrary python code

### What Works in Cron
- ✅ `browser_navigate` + `browser_snapshot` + `browser_scroll` — **RECOMMENDED primary method** (validated 2026-08-11)
- ✅ `web_search` — works for discovering repos
- ✅ `web_extract` — works for fetching pages/APIs
- ✅ `write_file` — works for saving JSON reports

---

## Method 1 (RECOMMENDED): browser_navigate + browser_snapshot + write_file

**Validated 2026-08-11** — produces the richest structured data.

### Workflow
1. `browser_navigate("https://github.com/trending")` — loads full page with element refs
2. `browser_snapshot(full=true)` — get structured AX tree with interactive elements
3. Parse from snapshot structure:
   - Repo name: `heading "owner/repo"` → link ref
   - Description: `paragraph` → `StaticText` after heading
   - Language: `StaticText "Python"` in generic element (inline with stars)
   - Stars: `link "star N,NNN"`
   - Forks: `link "fork N,NNN"`
   - Today's stars: `StaticText " NNN stars today"`
4. `browser_scroll("down")` + another `browser_snapshot` if more repos needed
5. `write_file("trending_repos.json", json_string)` — save JSON directly

### Advantages over web_extract
- Structured element tree — easier to parse reliably
- Language info always available inline (web_extract sometimes omits it)
- Star/fork counts in structured link elements
- Can scroll for additional repos

### Limitations
- GitHub Trending page renders ~8-10 repos per viewport
- Scroll down for more, but page may cut off last 1-2 repos
- Some repos may lack language info in the snapshot (estimate from repo description/topics)

---

## Method 2 (Fallback): web_search + web_extract

If browser tools are unavailable:
1. `web_search("site:github.com trending repositories today")` — structured search results
2. `web_extract(["https://github.com/trending"])` — full page as markdown

web_extract output format (may vary):
```
### 1. [owner/repo-name](url)
- **Description**: text
- **Language**: Python
- **Stars**: 12,345 | **Forks**: 1,234
- **Today's Stars**: **456**
```

---

## JSON Report Generation
Use `write_file` tool to save JSON directly — no terminal/python needed.
Build the JSON structure in your response logic, then write with write_file.

---

## Validated Session Log

| Date | Method | Result | Notes |
|------|--------|--------|-------|
| 2026-08-09 | web_search + web_extract + write_file | ✅ | Standard fallback approach |
| 2026-08-11 | browser_navigate + browser_snapshot(full=true) + write_file | ✅ | Richer data, language inline |
| 2026-08-11 | execute_code | ❌ BLOCKED | Security policy |
| 2026-08-11 | terminal("python3 -c ...") | ❌ BLOCKED | Tirith tirith:unknown |
