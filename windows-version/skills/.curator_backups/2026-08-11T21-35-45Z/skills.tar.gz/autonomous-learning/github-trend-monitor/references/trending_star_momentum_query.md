# Trending by Star Momentum Pattern

**Verified**: 2026-05-17, cron job context

## Problem with `sort=updated`

The default `sort=updated` query returns repos that recently had a commit — but this biases toward large established projects (React, VS Code, etc.) that always have activity. It does NOT answer "what's trending right now."

## Better Pattern: `created:>DATE` + `sort=stars`

```python
# Find repos created in the last 30 days, sorted by star count
# This captures GENUINELY TRENDING projects — new repos gaining massive momentum
browser_navigate(url="https://api.github.com/search/repositories?q=stars:%3E500+created:%3E2026-04-17&sort=stars&order=desc&per_page=10")
```

### Why This Works Better

- `created:>DATE` filters to recently created repos only
- `sort=stars` ranks by total star count (proxy for momentum)
- Result: repos that got 500+ stars in a short window = genuinely trending
- Date window: use 30 days (`today - 30d`) for the sweet spot

### Date Encoding

URL-encode `>` as `%3E`:
- `stars:%3E500` = stars > 500
- `created:%3E2026-04-17` = created after April 17, 2026

### JavaScript Extraction

```javascript
JSON.parse(document.body.innerText).items.map(r => ({
    full_name: r.full_name,
    url: r.html_url,
    stars: r.stargazers_count,
    language: r.language || 'Unknown',
    description: r.description || '',
    topics: r.topics || [],
    created_at: r.created_at,
    forks: r.forks_count,
    open_issues: r.open_issues_count,
    license: r.license?.spdx_id || 'N/A'
}))
```

## Observed Results (2026-05-17)

### Run 1 (morning, no date filter on topic queries)
General query: `stars:>500 created:>2026-04-17 sort:stars desc` (205 matching).
Topic queries used plain `sort:stars` WITHOUT `created:>DATE` — returned established projects.

Top 10 strong signals:
1. **Design tools dominated** (4/10) — AI-driven design/prototype generation
2. **Agent Skills ecosystem** (5/10) — codex/hermes skills becoming standalone products
3. **GPT-Image-2 ecosystem** (2/10) — image generation API prompt engineering

Key finding: `nexu-io/open-design` (42K stars in 19 days!) had `hermes-agent` in its topics — upstream projects are actively targeting the Hermes ecosystem.

### Run 2 (afternoon, `created:>DATE` on ALL 3 queries)
Same 3-query strategy but with `created:>2026-04-17` applied to topic queries too.
Result: **21 unique repos** (vs 26 in Run 1). **Dramatically different ecosystem snapshots.**

| Query | Without date filter (Run 1) | With date filter (Run 2) |
|-------|----------------------------|--------------------------|
| topic:agent | Dify, OpenHands, MetaGPT (established) | garden-skills, DeepSeek-Reasonix, open-slide (new) |
| topic:mcp | n8n, everything-claude-code (established) | awesome-agentic-ai-zh, opensquilla, arkon (new) |

**Key insight**: Applying `created:>DATE` to topic queries filters out established mega-projects and surfaces genuinely NEW ecosystem entrants. Both views are valuable:
- **Without date filter** = ecosystem **baseline** (what exists)
- **With date filter** = ecosystem **momentum** (what's emerging)

## Recommended Query Strategy

| Query | When to Use |
|-------|-------------|
| `created:>DATE + sort=stars` (general) | Daily trend monitoring (what's HOT) |
| `sort=updated` (general) | Looking for actively maintained repos |
| `topic:agent + sort:stars` (no date) | Agent ecosystem **baseline** (what exists) |
| `topic:agent + created:>DATE + sort:stars` | Agent ecosystem **momentum** (new entrants) |
| `topic:mcp + sort:stars` (no date) | MCP ecosystem **baseline** (what exists) |
| `topic:mcp + created:>DATE + sort:stars` | MCP ecosystem **momentum** (new entrants) |

**Baseline vs Momentum**: Without `created:>DATE`, topic queries return the full ecosystem (n8n, Dify, etc.). With `created:>DATE`, they surface only NEW entrants gaining rapid traction. Both are useful — use baseline for landscape mapping, momentum for opportunity scouting.
