"""
GitHub Trending Analysis Template — 2026-05-13 (fetch step updated 2026-05-16)

PASTE THIS INTO execute_code AFTER fetching data via browser_console.

The FETCH step (Step 1) must use browser_navigate + browser_console (see
browser_console_api_pattern.md). Then feed the resulting repos list into
Steps 2-4 below for analysis, saving, and reporting.

If using browser_console, your data comes back as:
  result = browser_console(expression="JSON.parse(document.body.innerText).items")
  repos_raw = result['result']  # list of raw API repo objects
  # Then map each repo_raw into the normalized format below
"""
import json
from collections import Counter

# --- Step 1 (TEMPLATE): Normalize raw API data ---
# Replace this with actual data from browser_console
# repos_raw = [...]  # from browser_console result

def normalize_repo(r):
    return {
        "name": r["full_name"],
        "description": r.get("description") or "",
        "language": r.get("language") or "Unknown",
        "stars": r["stargazers_count"],
        "forks": r["forks_count"],
        "open_issues": r["open_issues_count"],
        "url": r["html_url"],
        "topics": r.get("topics", []),
        "created": r["created_at"],
        "updated": r["updated_at"],
        "license": (r.get("license") or {}).get("spdx_id", "N/A")
    }

# repos = [normalize_repo(r) for r in repos_raw]

# --- Step 2: Analyze ---
keyword_set = [
    "ai", "llm", "agent", "mcp", "api", "cli", "tool", "automation",
    "model", "inference", "deploy", "rust", "python", "typescript", "go",
    "gpu", "framework", "database", "security", "embed", "rag", "vector"
]

def analyze_repos(repos):
    lang_counts = Counter(r["language"] for r in repos)
    
    keywords_list = []
    for r in repos:
        desc = (r["description"] or "").lower()
        for kw in keyword_set:
            if kw in desc:
                keywords_list.append(kw)
    keyword_counts = Counter(keywords_list)
    
    hermes_opportunities = []
    for r in repos:
        desc = (r["description"] or "").lower()
        topics = " ".join(r.get("topics", [])).lower()
        combined = desc + " " + topics
        reasons = []
        if any(kw in combined for kw in ["mcp", "model context protocol"]):
            reasons.append("MCP协议相关 — 可直接集成")
        if any(kw in combined for kw in ["api", "rest", "sdk"]):
            reasons.append("API/SDK — 可作为工具集成")
        if any(kw in combined for kw in ["cli", "command line", "terminal"]):
            reasons.append("CLI工具 — 可封装为skill")
        if any(kw in combined for kw in ["agent", "automation", "workflow"]):
            reasons.append("Agent/自动化 — 架构参考")
        if any(kw in combined for kw in ["llm", "ai", "model", "inference"]):
            reasons.append("AI/LLM相关 — 能力扩展")
        if any(kw in combined for kw in ["github", "git", "ci", "cd", "devops"]):
            reasons.append("DevOps/GitHub — 工作流集成")
        if any(kw in combined for kw in ["embed", "rag", "vector"]):
            reasons.append("Embedding/RAG — 知识库增强")
        if reasons:
            hermes_opportunities.append({"repo": r["name"], "stars": r["stars"], "reasons": reasons})
    
    return lang_counts, keyword_counts, hermes_opportunities

# --- Step 3: Save ---
def save_report(repos, lang_counts, keyword_counts, hermes_opportunities):
    output_path = "/Users/macpro/.hermes/hermes-agent/trending_repos.json"
    output = {
        "timestamp": "AUTO",  # replace with actual timestamp
        "query": "stars:>500, sort:updated, top 10",
        "total_repos": len(repos),
        "repos": repos,
        "analysis": {
            "language_distribution": dict(lang_counts),
            "top_keywords": dict(keyword_counts.most_common(10)),
            "hermes_integration_opportunities": hermes_opportunities
        }
    }
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    return output_path

# --- Step 4: Report ---
def generate_report(repos, lang_counts, keyword_counts, hermes_opportunities, output_path):
    lines = []
    lines.append(f"✅ 已保存 {len(repos)} 个仓库到 {output_path}")
    lines.append("")
    lines.append(f"📊 语言分布: {dict(lang_counts)}")
    lines.append(f"🔑 热门关键词: {dict(keyword_counts.most_common(10))}")
    lines.append(f"🎯 Hermes集成机会: {len(hermes_opportunities)} 个仓库")
    for opp in hermes_opportunities:
        lines.append(f"  ⭐ {opp['repo']} ({opp['stars']:,} stars) — {'; '.join(opp['reasons'])}")
    lines.append("")
    lines.append("📋 Top 10 仓库列表:")
    for i, r in enumerate(repos, 1):
        desc_short = (r['description'] or 'N/A')[:70]
        lines.append(f"  {i:2d}. {r['name']:45s} ⭐{r['stars']:>10,} | {r['language']:12s} | {desc_short}")
    return "\n".join(lines)
