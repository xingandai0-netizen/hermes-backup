# Bilingual Report Template

Use this format for the inline cron report (auto-delivered).

```markdown
## 📊 GitHub 趋势监控报告 — YYYY-MM-DD

**查询条件**: `stars:>500, sort:updated, top 10`
**数据来源**: GitHub Trending + AttentionVC + wangchujiang.com

### 📋 Top 10 仓库

| # | 仓库 | ⭐ Stars | 今日增长 | 语言 | 简介 |
|---|------|---------|---------|------|------|
| 1 | [owner/repo](url) | 12,345 | +123 | Python | Description... |

### 📈 语言分布

```
Python:     ████████████████████ 4个 (40%)
JavaScript: ███████████████ 3个 (30%)
TypeScript: █████ 1个 (10%)
```

### 🔑 热门关键词

`agent(4)` > `python(4)` > `ai(3)` > `tool(2)` > `skill(2)` > `mcp(1)`

### 🎯 Hermes 集成机会分析 (N/10 仓库有潜在价值)

| 仓库 | Stars | 今日增长 | 机会类型 | 优先级 |
|------|-------|---------|---------|--------|
| [owner/repo](url) | 12.3K | +123 | 🔌 MCP集成 — 具体理由 | 高 |

### 💡 重点发现

1. **repo-name** — 为什么值得关注，建议行动

### 📊 技术趋势洞察

- **趋势1**: 描述
- **趋势2**: 描述

---

✅ 结果已保存至 `/Users/macpro/trending_repos.json`
📅 报告生成时间: YYYY-MM-DD
```

## Format Rules

- **Stars formatting**: Use `f"{stars:,}"` for thousands separator (e.g., 12,345)
- **Description truncation**: Max 70 chars with `[:70]`
- **Bilingual**: Section headers in Chinese, technical content in English
- **Emoji markers**: Each section has a distinctive emoji for visual scanning
- **Priority levels**: 高 (HIGH), 中 (MEDIUM), 低 (LOW)
- **Bar chart**: Use Unicode block characters (█░) for language distribution
