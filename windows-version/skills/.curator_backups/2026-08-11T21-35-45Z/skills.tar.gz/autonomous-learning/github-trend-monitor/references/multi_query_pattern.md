# Multi-Dimensional API Query Pattern

**Verified**: 2026-05-16, cron job context

## Why Multiple Queries

A single GitHub Search API query gives limited perspective. Three complementary queries reveal the full ecosystem:

| Query | URL | Purpose |
|-------|-----|---------|
| General recent | `q=stars:%3E500&sort=updated&order=desc&per_page=10` | What's being actively developed |
| AI/Agent ecosystem | `q=topic:agent+stars:%3E1000&sort=stars&order=desc&per_page=10` | Agent landscape by popularity |
| MCP ecosystem | `q=topic:mcp+stars:%3E500&sort=stars&order=desc&per_page=10` | MCP integration opportunities |

## Execution Pattern

Run sequentially (not parallel — browser can only navigate one URL at a time):

```python
# Query 1: General
browser_navigate(url="https://api.github.com/search/repositories?q=stars:%3E500&sort=updated&order=desc&per_page=10")
result1 = browser_console(expression="""
try {
    const data = JSON.parse(document.body.innerText);
    const items = data.items || [];
    JSON.stringify({
        total_count: data.total_count,
        repos: items.map(r => ({
            name: r.full_name,
            stars: r.stargazers_count,
            forks: r.forks_count,
            language: r.language,
            description: (r.description || '').substring(0, 150),
            updated: r.updated_at.substring(0, 10),
            url: r.html_url,
            topics: (r.topics || []).slice(0, 8)
        }))
    });
} catch(e) { 'Error: ' + e.message; }
""")

# Query 2: Agent ecosystem
browser_navigate(url="https://api.github.com/search/repositories?q=topic:agent+stars:%3E1000&sort=stars&order=desc&per_page=10")
result2 = browser_console(expression="/* same extraction JS */")

# Query 3: MCP ecosystem
browser_navigate(url="https://api.github.com/search/repositories?q=topic:mcp+stars:%3E500&sort=stars&order=desc&per_page=10")
result3 = browser_console(expression="/* same extraction JS */")
```

## Tips

- `browser_console` returns the result of the last expression — use `JSON.stringify(...)` to ensure structured return
- Always wrap in try/catch since the API might return error JSON
- The `description` field can be `null` — use `(r.description || '').substring(0, 150)`
- `topics` array may be empty — always use `(r.topics || []).slice(0, 8)`
- Each query counts as 1 API request against the 10 req/min unauthenticated rate limit
- Three queries = 3 requests, well within limits
