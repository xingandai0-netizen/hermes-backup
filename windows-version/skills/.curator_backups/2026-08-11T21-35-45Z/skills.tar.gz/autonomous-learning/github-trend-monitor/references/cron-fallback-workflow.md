# Cron Mode Fallback Workflow

When running as a scheduled cron job, both `terminal` and `execute_code` are blocked by Tirith security scan.

## Fallback Method: web_search + write_file

### Step 1: Gather Trending Data
```
web_search(query="GitHub trending repositories today 2026", limit=10)
web_search(query="GitHub trending AI machine learning repositories this week", limit=10)
```
The GitHub trending page (github.com/trending) is JS-rendered — `web_extract` returns "Loading". Third-party mirrors that work:
- orangebot.ai/github-trending-today
- trending.magikaru.com
- gittrend.io/monthly/YYYY-MM
- trendsmcp.ai (has API)

### Step 2: Parse Data from Search Results
Extract from the search result descriptions:
- Repository name (org/repo)
- Stars and today's star delta
- Language
- Description
- URL

The github.com/trending search result often contains the full page HTML including star counts.

### Step 3: Write Report
```python
# Using write_file tool to write JSON reports
# Reports directory: /Users/macpro/reports/
# Files to create:
#   - trend_data_YYYYMMDD.json  (permanent record)
#   - latest_data.json          (overwrite with latest)
```

Report JSON schema:
```json
{
  "generated_at": "ISO timestamp",
  "report_type": "daily_trends",
  "summary": {
    "total_repos": int,
    "languages": {"Python": int, ...},
    "avg_stars": int,
    "total_today_stars": int,
    "investment_opportunities": int
  },
  "repositories": [
    {
      "name": "org/repo",
      "description": "string",
      "stars": int,
      "language": "string",
      "url": "https://github.com/org/repo",
      "today_stars": int
    }
  ],
  "investment_opportunities": [
    {"name": "org/repo", "stars": int, "reason": "string"}
  ],
  "metadata": {
    "generator": "Auto-Tech-Trend-Consulting",
    "version": "1.0.0",
    "data_source": "github.com/trending (web_search fallback)",
    "generation_method": "web_search + write_file (terminal blocked)"
  }
}
```

### Step 4: Update Run Logs
```csv
# /Users/macpro/data/run_log.csv — append row:
# timestamp,report_status,email_status,repos,languages,opportunities,avg_stars,errors
2026-08-10T09:00:00,SUCCESS,SIMULATED,12,7,6,58758,none(web_search+write_file_fallback)

# /Users/macpro/data/system_run_log.csv — append row:
# timestamp,run_type,method,model,status,notes
2026-08-10T09:00:00+08:00,DAILY_RUN,web_search+write_file,MiMo-v2.5-pro,SUCCESS,notes
```

### Step 5: System Status Report
Write `/Users/macpro/reports/system_status_YYYYMMDD.json` with component health.

### Step 6: Email Status
Mark as SIMULATED — cannot run email_automation.py. Document subscriber count (5 active subscribers in data/subscribers.csv).

## Investment Opportunity Criteria
Flag repos as investment opportunities when:
- Daily star gain > 200
- OR total stars > 50K with consistent growth
- OR domain relevance (AI+Finance, Agent Security, Code RAG)
- OR big tech involvement (Google, Microsoft, ByteDance)

## Subscriber List
Active subscribers in /Users/macpro/data/subscribers.csv:
- tech.director@company.com (张三) — tech-director, enterprise
- cto@startup.io (李四) — cto, startup
- architect@bigcorp.com (王五) — architect, enterprise
- dev.lead@agency.com (赵六) — team-lead, agency
- founder@techstartup.com (钱七) — founder, startup
