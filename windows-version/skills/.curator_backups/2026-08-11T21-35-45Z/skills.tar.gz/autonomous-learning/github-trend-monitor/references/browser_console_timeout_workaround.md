# Browser Console Timeout Workaround — GitHub Trending

**Date**: 2026-08-06  
**Model**: MiMo-v2.5-pro  
**Context**: Cron job, SSL failure on all web_* tools

## Problem

`browser_console` DOM extraction expression timed out (30s) on GitHub Trending page when using verbose field names and longer substring limits.

### ❌ Timed Out (30s)
```javascript
(function(){
  const articles = document.querySelectorAll('article');
  const repos = [];
  articles.forEach(a => {
    // ... extraction with:
    const description = descEl ? descEl.textContent.trim() : '';
    repos.push({
      description: description.substring(0, 200),  // ← longer limit
      language: language,                            // ← verbose name
      today_stars: parseInt(todayStars) || 0         // ← verbose name
    });
  });
  return JSON.stringify(repos, null, 2);  // ← pretty-printed
})()
```

### ✅ Succeeded (~2s)
```javascript
(function(){
  const articles = document.querySelectorAll('article');
  const repos = [];
  articles.forEach(a => {
    // ... extraction with:
    const desc = descEl ? descEl.textContent.trim() : '';
    repos.push({
      name: fullName,
      desc: description.substring(0, 100),  // ← shorter limit
      lang: language,                        // ← abbreviated name
      stars: parseInt(starsText) || 0,
      today: parseInt(todayStars) || 0       // ← abbreviated name
    });
  });
  return JSON.stringify(repos);  // ← no pretty-print
})()
```

## Key Differences

| Factor | Timed Out | Succeeded |
|--------|-----------|-----------|
| `substring` limit | 200 | 100 |
| Field names | verbose (`description`, `language`, `today_stars`) | short (`desc`, `lang`, `today`) |
| `JSON.stringify` | `null, 2` (pretty) | default (compact) |
| Total payload | ~3KB+ | ~2KB |

## Root Cause

The GitHub Trending page has complex DOM with many `<article>` elements. The `browser_console` expression runs in the browser's DevTools console context with a 30-second timeout. Verbose JSON serialization + longer string extraction on 13+ articles can exceed this limit.

## Recommendations

1. **Keep field names short** in browser_console extraction — use `desc` not `description`, `lang` not `language`
2. **Limit substring to 100 chars** — sufficient for trending descriptions, reduces serialization cost
3. **Skip JSON.stringify pretty-printing** — `null, 2` doubles the payload size for no benefit when parsing programmatically
4. **If timeout persists**, extract fewer fields or limit to top 10 articles: `articles.forEach((a, i) => { if(i >= 10) return; ... })`

## Also Note

- `browser_snapshot(full=True)` also timed out on this page (same 30s limit) — the full AX tree for GitHub Trending is very large
- `browser_snapshot` (compact, default) succeeded but only returned ~5 repos before truncation
- The compact browser_console expression is the best method for extracting 10+ repos from GitHub Trending
