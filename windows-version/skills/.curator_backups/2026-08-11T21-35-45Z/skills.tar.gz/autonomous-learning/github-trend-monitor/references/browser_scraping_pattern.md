## Browser Scraping Pattern for GitHub Trending (verified 2026-05-15)

Use this as the PRIMARY data source for GitHub trend monitoring in cron jobs.

### Step 1: Navigate to Trending Page

```
browser_navigate(url="https://github.com/trending?since=daily")
```

### Step 2: Get Full Snapshot

```
browser_snapshot(full=True)
```

### Step 3: Parse Repo Data from Snapshot

The snapshot returns structured accessibility tree. Each repo appears as an `article` element containing:
- `heading` with repo name (e.g., "owner/repo") → link text
- `paragraph` with description
- Language in a `StaticText` child of the `generic` container
- Star/fork counts in `link` elements with text like "star 192,190" and "fork 17,091"
- "X stars today" as a trailing `StaticText`

### Parsing Tips

- Repo names appear in `heading` elements level 2 inside each `article`
- Stars format: `"star 192,190"` — strip "star " prefix, remove commas, int() it
- Language: appears as a `StaticText` before the star links (e.g., `StaticText "Rust"`)
- Some repos show "Sponsor" label before the Star link — skip those
- "N stars today" appears as the last StaticText in each article

### Output Format

Save to `trending_repos.json`:
```json
{
  "fetched_at": "ISO-8601 timestamp",
  "source": "https://github.com/trending?since=daily",
  "repos": [
    {
      "rank": 1,
      "full_name": "owner/repo",
      "url": "https://github.com/owner/repo",
      "stars": 192190,
      "forks": 17091,
      "stars_today": 1780,
      "language": "Shell",
      "description": "Description text",
      "keywords": ["extracted", "keywords"]
    }
  ],
  "language_distribution": {"Rust": 2, "Python": 1},
  "hermes_integration_opportunities": [...]
}
```

### Edge Cases

- GitHub may show fewer than 10 repos on some days
- `@claude` frequently appears as a contributor — this is normal for AI-assisted repos
- Some repos have no language listed — mark as "Unknown"
- The page may have "Sponsored" repos mixed in — they have a "Sponsor" link before the Star link
