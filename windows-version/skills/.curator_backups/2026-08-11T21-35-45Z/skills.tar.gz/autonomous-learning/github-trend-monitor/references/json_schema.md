# JSON Report Schema

Used by `write_file` to save trending data when `execute_code` is blocked.

```json
{
  "metadata": {
    "generated_at": "ISO-8601 timestamp",
    "query": "search query used",
    "source": "data sources (e.g., 'GitHub Trending + AttentionVC')",
    "date": "YYYY-MM-DD"
  },
  "top_10_by_stars": [
    {
      "name": "owner/repo",
      "url": "https://github.com/owner/repo",
      "description": "repo description (max 200 chars)",
      "stars": 12345,
      "language": "Python|JavaScript|TypeScript|Rust|Go|C|...",
      "today_stars": 123
    }
  ],
  "language_distribution": {
    "Python": 4,
    "JavaScript": 3
  },
  "keyword_frequency": {
    "ai": 3,
    "agent": 4,
    "mcp": 1
  },
  "hermes_integration_opportunities": [
    {
      "repo": "owner/repo",
      "stars": 12345,
      "today_stars": 123,
      "opportunities": ["MCP集成", "Agent自动化", "API/CLI工具", "安全工具", "成本优化", "Agent Skills生态"]
    }
  ],
  "summary": {
    "total_repos": 10,
    "avg_stars": 50000,
    "total_today_stars": 500,
    "top_language": "Python"
  }
}
```

## Field Notes

- `stars`: Total star count (integer, no commas)
- `today_stars`: Stars gained in last 24h (from trending page or tracker snippets)
- `language`: Primary language (use "N/A" if null)
- `opportunities`: Array of integration categories (see Hermes Integration Scoring in SKILL.md)
- `keyword_frequency`: Count of repos where keyword appears in description or name
