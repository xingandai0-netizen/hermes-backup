# Working Data Sources for GitHub Trend Monitor

## Primary: github-trending.today
- URL: `https://github-trending.today/?since=daily` (also `?since=weekly`, `?since=monthly`)
- Access: via `web_extract` tool — returns clean markdown with repo names, languages, star counts
- Format: Each repo as `## [owner/repo](url)` + description + language + star/fork/issue counts
- Last verified working: 2026-07-03

## Secondary: github.attentionvc.ai
- URL: `https://github.attentionvc.ai/trending/repos`
- Has daily/weekly tabs, category filters (AI, MCP, Agents, OpenClaw, Skills, Coding, etc.)
- **web_extract works reliably** (verified 2026-07-04) — returns clean markdown with top 25 repos, stars, daily delta
- Best source for category-filtered data and daily star velocity

## Tertiary: gitgazette.com
- URL: `https://gitgazette.com/trending`
- **web_extract works** (verified 2026-07-04) — returns structured trending data with star counts and daily growth
- Good supplementary source for cross-referencing and validation

## Fallback: web_search
- Query: `github trending repositories today` or `github trending repos daily`
- Returns multiple sources including github-trending.today, medium articles, attentionvc data
- Parse the first result's description for repo listings

## GitHub Search API (UNRELIABLE in cron)
- Endpoint: `https://api.github.com/search/repositories?q=stars:>500+pushed:>YYYY-MM-DD&sort=updated&order=desc&per_page=10`
- Works from terminal with curl but frequently times out (30s) in cron/sandboxed environments
- Rate limit: 10 req/min without token

## Verification Log

| Date | Source | web_extract | Notes |
|------|--------|-------------|-------|
| 2026-07-04 | github.com/trending | ✅ | 17 repos, clean markdown |
| 2026-07-04 | attentionvc.ai/trending/repos | ✅ | 25 repos with daily deltas and categories |
| 2026-07-04 | gitgazette.com/trending | ✅ | 10+ repos with star growth |
| 2026-07-03 | github-trending.today | ✅ | Previous primary source |

## Output JSON Schema
```json
{
  "generated_at": "ISO8601",
  "source": "github-trending.today (daily)",
  "filter": "description of filter applied",
  "total_repos": 10,
  "repos": [
    {
      "rank": 1,
      "name": "owner/repo",
      "url": "https://github.com/owner/repo",
      "description": "...",
      "language": "Python",
      "stars": 32054,
      "forks": 2167,
      "open_issues": 3364,
      "topics": [],
      "hermes_integration": {
        "score": 7,
        "type": ["CLI", "MCP", "skill"],
        "opportunity": "description of integration opportunity"
      }
    }
  ],
  "analysis": {
    "language_distribution": {"Python": 3, "JavaScript": 3},
    "top_keywords": [],
    "avg_stars": 0,
    "trend_summary": "one-line summary"
  },
  "hermes_opportunities": [
    {
      "priority": "CRITICAL|HIGH|MEDIUM|LOW",
      "repo": "owner/repo",
      "action": "specific next step"
    }
  ]
}
```

## Hermes Integration Scoring Guide
- **10**: Already integrated or directly usable as Hermes skill/MCP (e.g., superpowers)
- **9**: High-value MCP server or skill framework that fills a capability gap
- **7-8**: CLI/API tool that could be wrapped as a Hermes skill
- **5-6**: Reference architecture or methodology worth studying
- **3-4**: Niche domain tool, low general applicability
- **1-2**: No clear Hermes connection
