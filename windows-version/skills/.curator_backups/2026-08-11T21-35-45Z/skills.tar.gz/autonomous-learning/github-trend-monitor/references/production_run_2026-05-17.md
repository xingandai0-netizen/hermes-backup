# Production Run Observations — 2026-05-17

## Run 1 — Morning (full pipeline with HTML + email)

### What Worked
1. **3-query browser strategy** produced 26 unique repos from 45 fetched (33% dedup)
2. **browser_console JSON.parse** worked on all 3 API endpoints without any issues
3. **execute_code + hermes_tools.write_file** saved 5 files (2 JSON, 1 HTML, 2 "latest" copies) successfully
4. **Daily run log** appended correctly to JSONL format
5. **Email simulation** logged 5 sends to CSV
6. **Pipeline timing**: ~4 seconds for the execute_code phase (merge + analyze + save all files)

## Data Quality Notes
- `trending_star_momentum` query (created:>2026-04-17) found 205 total matching repos, top 15 fetched
- `topic:agent` returned well-known repos (Dify, OpenHands, MetaGPT) — good ecosystem baseline
- `topic:mcp` returned n8n, everything-claude-code, cc-switch — strong MCP ecosystem signal
- Several trending repos had hermes-agent in their topics (open-design, cc-switch) — ecosystem growing

## Report Stats
- 26 unique repos analyzed
- 8 high-priority Hermes integration opportunities
- 16 medium-priority opportunities
- Python dominated (50% of repos)
- Top repo: n8n-io/n8n (188K stars)

## HTML Report
- Dark theme (#0d1117 background) matched GitHub aesthetic
- Stats grid + repo cards + opportunity analysis sections rendered correctly
- Generated ~200KB HTML file

## Run 2 — Afternoon (JSON-only, `created:>DATE` on all queries)

### What Worked
1. **`created:>DATE` on topic queries** produced completely different (and more actionable) results
2. 3 browser_navigate + browser_console calls: ~15 seconds total
3. execute_code merge + save: ~1.5 seconds
4. Total unique repos: 21 (vs 26 in Run 1 without date filter)
5. High-priority opportunities: 5 (all MCP-related — arkon, opensquilla, etc.)
6. Medium-priority: 15

### Key Discovery: Baseline vs Momentum
- Without date filter: topic queries return established mega-projects (n8n 188K, Dify)
- With date filter: returns genuinely NEW ecosystem entrants (arkon, opensquilla, agents-best-practices)
- **Recommendation**: Run both variants on different schedules (baseline weekly, momentum daily)

### Improvements for Next Run
- Consider adding a "trending page" scrape via browser_snapshot for star velocity data
- The email simulation could be enhanced with actual SMTP if credentials are configured
- Could add week-over-week comparison by loading previous reports

## Run 3 — Evening (JSON-only, single Search API query)

### What Happened
- Cron job loaded the skill via `skills_list` + `skill_view` (skill was listed as "not found" in cron preamble but recovered manually)
- Used single `browser_navigate` to GitHub Search API (`sort=updated`)
- Extracted via `browser_console` with `JSON.parse(document.body.innerText).items.map(...)`
- Saved to `trending_repos.json` via `execute_code` + `hermes_tools.write_file`
- Generated inline bilingual report with language distribution + keyword analysis + integration opportunities

### Results
- 10 repos fetched, all with stars > 500
- Language distribution: Python 30%, Adblock Filter List 20%, JS/Kotlin/C++/Tcl 10% each
- Top repo by stars: PostHog/posthog (34.5K)
- 5 integration opportunities identified (PostHog, clawd-on-desk, free-proxy-list, EtherGhost, macports)
- High-priority: PostHog (API integration), clawd-on-desk (coding agent ecosystem)

### Pitfall Hit: `null` vs `None`
- JSON data from API contains `null` for language field
- When manually reconstructing Python dicts for analysis, used `null` instead of `None`
- Caused `NameError: name 'null' is not defined`
- Fix: Always use Python `None` when building dicts from API data in `execute_code`
- **Better approach**: Let `browser_console` return processed data via JS rather than copying raw JSON fields into Python code. Extract via JS → analyze in Python is cleaner and avoids the null/None mismatch entirely.

### Observations
- Single query (sort=updated) returned mostly large active projects (PostHog 34K, uBlock 5.7K) — consistent with the documented bias
- Multi-query strategy (Run 1/2) would have found more genuinely trending repos
- The skill's recommended approach (3-query with created:>DATE) remains superior
