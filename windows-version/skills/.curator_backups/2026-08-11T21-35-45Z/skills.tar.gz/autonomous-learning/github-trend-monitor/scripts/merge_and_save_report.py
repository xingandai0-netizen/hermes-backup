#!/usr/bin/env python3
"""
Merge multi-query GitHub API results into a unified trend report.
Run inside execute_code — expects 3 variables set by the caller:

    general_repos  = [ {...}, ... ]   # from Query 1 (general/updated)
    agent_repos    = [ {...}, ... ]   # from Query 2 (topic:agent)
    mcp_repos      = [ {...}, ... ]   # from Query 3 (topic:mcp)

Outputs:
    /Users/macpro/.hermes/hermes-agent/trending_repos.json
    /Users/macpro/reports/trend_data_<YYYYMMDD_HHMMSS>.json

Returns: summary dict with stats for the report.
"""

import json
from datetime import datetime
from hermes_tools import write_file

# --- Integration keyword sets (update as ecosystem evolves) ---
KEYWORDS_MCP = ["mcp", "model-context-protocol"]
KEYWORDS_AGENT = ["agent", "automation", "workflow", "orchestrat", "pipeline", "harness"]
KEYWORDS_API = ["api", "sdk", "cli", "tool", "framework", "library"]
KEYWORDS_AI = ["llm", "ai", "model", "inference", "fine-tuning"]
KEYWORDS_DEVOPS = ["github", "git", "ci", "cd", "devops", "docker"]

timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
ts_file = datetime.now().strftime("%Y%m%d_%H%M%S")

# --- Deduplicate across queries ---
seen = set()
all_repos = []
for r in general_repos + agent_repos + mcp_repos:
    if r["name"] not in seen:
        seen.add(r["name"])
        all_repos.append(r)

# --- Language distribution ---
lang_count = {}
for r in all_repos:
    lang = r.get("language") or "N/A"
    lang_count[lang] = lang_count.get(lang, 0) + 1
lang_dist = dict(sorted(lang_count.items(), key=lambda x: -x[1]))

# --- Integration analysis ---
priority_order = {"高": 0, "中": 1, "低": 2}
opportunities = []
for r in all_repos:
    text = f"{r.get('description','').lower()} {r['name'].lower()} {' '.join(r.get('topics', []))}"
    matches, priority = [], "低"
    if any(k in text for k in KEYWORDS_MCP):
        matches.append("MCP集成"); priority = "高"
    if any(k in text for k in KEYWORDS_AGENT):
        matches.append("Agent/自动化")
        if priority != "高": priority = "中"
    if any(k in text for k in KEYWORDS_API):
        matches.append("API/CLI工具")
        if priority == "低": priority = "中"
    if any(k in text for k in KEYWORDS_AI):
        matches.append("AI/LLM能力")
        if priority == "低": priority = "中"
    if any(k in text for k in KEYWORDS_DEVOPS):
        matches.append("DevOps集成")
    if matches:
        opportunities.append({
            "repo": r["name"], "stars": r["stars"],
            "matches": matches, "priority": priority,
            "reason": f"涉及 {', '.join(matches)} — {r.get('description','')[:80]}"
        })
opportunities.sort(key=lambda x: (priority_order.get(x["priority"], 3), -x["stars"]))

# --- Top 10 by stars ---
top10 = sorted(all_repos, key=lambda x: -x["stars"])[:10]
top10_list = [{
    "rank": i + 1, "name": r["name"], "stars": r["stars"],
    "language": r.get("language") or "N/A",
    "description": (r.get("description") or "")[:70], "url": r["url"]
} for i, r in enumerate(top10)]

# --- Build report ---
report = {
    "generated_at": timestamp,
    "queries": {
        "general": {"total_matching": len(general_repos), "repos": general_repos},
        "agent_ecosystem": {"total_matching": len(agent_repos), "repos": agent_repos},
        "mcp_ecosystem": {"total_matching": len(mcp_repos), "repos": mcp_repos},
    },
    "language_distribution": lang_dist,
    "top_10_by_stars": top10_list,
    "hermes_integration_opportunities": opportunities,
}

# --- Save ---
report_json = json.dumps(report, indent=2, ensure_ascii=False)
write_file(path="/Users/macpro/.hermes/hermes-agent/trending_repos.json", content=report_json)
write_file(path=f"/Users/macpro/reports/trend_data_{ts_file}.json", content=report_json)

# --- Summary for caller ---
summary = {
    "total_unique": len(all_repos),
    "top_repo": top10[0]["name"] if top10 else "N/A",
    "top_stars": top10[0]["stars"] if top10 else 0,
    "high_priority": len([o for o in opportunities if o["priority"] == "高"]),
    "medium_priority": len([o for o in opportunities if o["priority"] == "中"]),
    "low_priority": len([o for o in opportunities if o["priority"] == "低"]),
    "lang_dist": lang_dist,
    "high_priority_repos": [{"repo": o["repo"], "stars": o["stars"], "matches": o["matches"]} for o in opportunities if o["priority"] == "高"],
}
print(json.dumps(summary, indent=2, ensure_ascii=False))
