# Webhook Patterns Reference

## Common Patterns

### GitHub: New Issues
```bash
hermes webhook subscribe github-issues \
  --events "issues" \
  --prompt "New GitHub issue #{issue.number}: {issue.title}\n\nAction: {action}\nAuthor: {issue.user.login}\nBody:\n{issue.body}\n\nPlease triage this issue." \
  --deliver telegram \
  --deliver-chat-id "-100123456789"
```

### GitHub: PR Reviews
```bash
hermes webhook subscribe github-prs \
  --events "pull_request" \
  --prompt "PR #{pull_request.number} {action}: {pull_request.title}\nBy: {pull_request.user.login}\nBranch: {pull_request.head.ref}\n\n{pull_request.body}" \
  --skills "github-code-review" \
  --deliver github_comment
```

### Stripe: Payment Events
```bash
hermes webhook subscribe stripe-payments \
  --events "payment_intent.succeeded,payment_intent.payment_failed" \
  --prompt "Payment {data.object.status}: {data.object.amount} cents from {data.object.receipt_email}" \
  --deliver telegram
```

### CI/CD: Build Notifications
```bash
hermes webhook subscribe ci-builds \
  --events "pipeline" \
  --prompt "Build {object_attributes.status} on {project.name} branch {object_attributes.ref}\nCommit: {commit.message}" \
  --deliver discord
```

### Direct Delivery (No Agent, Zero LLM Cost)
```bash
hermes webhook subscribe antenna-matches \
  --deliver telegram \
  --deliver-chat-id "123456789" \
  --deliver-only \
  --prompt "🎉 New match: {match.user_name} matched with you!"
```

## Security

- Each subscription gets auto-generated HMAC-SHA256 secret (or provide `--secret`)
- Webhook adapter validates signatures on every POST
- Static routes from config.yaml cannot be overwritten by dynamic subscriptions

## How It Works

1. `hermes webhook subscribe` writes to `~/.hermes/webhook_subscriptions.json`
2. Webhook adapter hot-reloads this file on incoming request (mtime-gated)
3. When POST matches a route, adapter formats prompt and triggers agent run
4. Agent response delivered to configured target (Telegram, Discord, etc.)

## Troubleshooting

1. Is gateway running? `systemctl --user status hermes-gateway`
2. Is webhook server listening? `curl http://localhost:8644/health`
3. Check logs: `grep webhook ~/.hermes/logs/gateway.log | tail -20`
4. Signature mismatch? Verify secret matches `hermes webhook list`
5. Firewall/NAT? Use tunnel (ngrok, cloudflared) for local dev
6. Wrong event type? Check `--events` filter matches what service sends
