# Kanban Codex Lane Reference

## Overview

Hermes is always the task owner: it calls `kanban_show`, decides whether Codex is appropriate, creates/selects isolated workspace, starts/monitors Codex, reconciles diff, runs verification, and writes `kanban_complete`/`kanban_block`. Codex is an input lane only — never writes Kanban state directly.

## When to Use Codex Lane

Use when ALL true:
- Task is coding/refactor/docs/test with clear acceptance criteria
- Bounded diff evaluable in one run
- Repo can be isolated in git worktree/branch
- Hermes can run tests after Codex exits
- Prompt states all safety constraints

Do NOT use when:
- Task requires human judgment not in Kanban body
- Change touches secrets/credentials/production systems
- Small direct edit is faster
- Task is research-only

## Worktree Pattern

```bash
TASK_ID="${HERMES_KANBAN_TASK:-t_manual}"
REPO="/path/to/repo"
BASE="$(git -C "$REPO" rev-parse --abbrev-ref HEAD)"
SAFE_TASK="$(printf '%s' "$TASK_ID" | tr -cd '[:alnum:]_-')"
BRANCH="codex/${SAFE_TASK}/$(date -u +%Y%m%d%H%M%S)"
WORKTREE="/tmp/${SAFE_TASK}-codex-lane"

git -C "$REPO" worktree add -b "$BRANCH" "$WORKTREE" "$BASE"
```

## Mode Selection

- `codex exec --full-auto` — bounded one-shot edits
- Codex `/goal` — broader multi-step work with durable objective tracking

## Reconciliation Checklist

- [ ] git status shows only expected files
- [ ] git diff reviewed by Hermes
- [ ] No secrets/credentials included
- [ ] Safety constraints preserved
- [ ] Commits small enough to cherry-pick
- [ ] Hermes ran canonical tests independently
- [ ] Accepted commits applied to Hermes-owned workspace

## kanban_complete Metadata Schema

```json
{
  "codex_lane": {
    "used": true,
    "mode": "exec | goal | skipped",
    "worktree": "/absolute/path",
    "branch": "codex/t_xxx/20260508100000",
    "result": "accepted | rejected | partial | timed_out",
    "accepted_commits": ["<sha1>"],
    "rejected_reason": "",
    "tests_run": [{"command": "...", "exit_code": 0, "owner": "hermes"}],
    "artifacts": ["/path/to/log-or-patch"]
  }
}
```

## Key Rules

1. Hermes owns Kanban lifecycle. Codex must never call kanban tools.
2. Hermes owns final acceptance. Codex commits are untrusted until reviewed.
3. Hermes owns test execution. Codex test runs are advisory.
4. Hermes owns safety. Reject if safety boundaries changed.
5. Hermes owns cleanup. Kill stuck processes, remove temp worktrees.
