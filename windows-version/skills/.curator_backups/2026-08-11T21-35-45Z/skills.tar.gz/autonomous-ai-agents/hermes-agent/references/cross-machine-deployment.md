# Cross-Machine AI Deployment Reference

> Absorbed from `cross-machine-ai-deployment` skill (archived 2026-06-21).

## Core Workflow
Deploy AI assistant identity (CLAUDE.md/SOUL.md), memories, and configuration to new machines via GitHub backup repos.

## Backup Repo Structure
```
├── CLAUDE.md              # Claude CLI identity
├── SOUL.md                # Hermes identity
├── memory/
│   ├── MEMORY.md          # Agent memory
│   └── USER.md            # User profile
├── skills/                # Reference skills
└── restore.sh             # Self-recovery script
```

## Deployment Commands

**macOS/Linux:**
```bash
git clone https://github.com/OWNER/REPO.git ~/.ai-backup
cp ~/.ai-backup/CLAUDE.md ~/CLAUDE.md
```

**Windows PowerShell:**
```powershell
git clone https://github.com/OWNER/REPO.git "$HOME\.ai-backup"
Copy-Item "$HOME\.ai-backup\CLAUDE.md" "$HOME\CLAUDE.md"
```

## Critical Pitfalls
1. **Claude CLI vs Hermes skills directory** — Claude uses `~/.claude/skills/`, Hermes uses `~/.hermes/skills/`
2. **Claude CLI refuses self-modification** — User must manually deploy, AI cannot overwrite its own CLAUDE.md
3. **Private repos return 404 on raw download** — Use `git clone` instead
4. **PowerShell syntax** — No `&&` (use `;`), no `~` (use `$HOME`)
5. **Fine-grained tokens can't create repos** — Need classic token with `repo` scope

## Skills Installation Patterns

**Hermes:**
```bash
hermes skills install skill-name
```

**Claude CLI:**
```bash
npx skills add author/repo --skill skill-name --global
```

**Git-based (blocked skills):**
```bash
git clone URL ~/.hermes/skills/name
```

## Real-Time Collaboration (小黑 + 小黄)
```
小黑(Mac) → git push → GitHub → git pull → 小黄(Windows)
```
Always `git pull` before changes, `git push` after. Use `.gitignore` to exclude `node_modules/`, `.next/`, `__pycache__/`.
