# Hermes s6-overlay Container Supervision Reference

## Architecture at a Glance

```
/init                                  ← PID 1 (s6-overlay v3.2.3.0)
├── cont-init.d                        ← oneshot setup, runs as root
│   ├── 01-hermes-setup                ← UID remap, chown, seed, skills sync
│   └── 02-reconcile-profiles          ← restore profile gateway slots from persistent volume
├── s6-rc.d (static services)
│   ├── main-hermes/run                ← exec sleep infinity (no-op slot)
│   └── dashboard/run                  ← conditional: HERMES_DASHBOARD=1
├── /run/service (tmpfs, runtime-registered per-profile)
│   ├── gateway-coder/                 ← type=longrun, run, log/run
│   └── ...
└── CMD (main program)                 ← /opt/hermes/docker/main-wrapper.sh
    └── routes user args via s6-setuidgid
```

## Key Files

| Path | Role |
|---|---|
| `Dockerfile` | s6-overlay install + cont-init.d wiring |
| `docker/stage2-hook.sh` | UID remap, chown, seed, skills sync |
| `docker/cont-init.d/02-reconcile-profiles` | Restore profile gateway slots |
| `docker/main-wrapper.sh` | Container CMD, routes user args |
| `hermes_cli/service_manager.py` | S6ServiceManager: register/unregister/start/stop gateways |
| `hermes_cli/container_boot.py` | reconcile_profile_gateways() |

## Why Architecture B (CMD as main program, not s6-supervised)

1. cont-init.d scripts receive no CMD args — can't parse docker run args for service run scripts
2. `/run/s6/basedir/bin/halt` does NOT propagate exit code — containers always exit 143

So we use `ENTRYPOINT ["/init", "/opt/hermes/docker/main-wrapper.sh"]`. The program's exit code becomes the container exit code.

## Quick Recipes

```sh
# Verify s6 is PID 1
docker exec <c> sh -c 'cat /proc/1/comm; readlink /proc/1/exe'

# Inspect a profile gateway
docker exec <c> /command/s6-svstat /run/service/gateway-<name>

# Bring service up/down
docker exec <c> /command/s6-svc -u /run/service/gateway-<name>   # up
docker exec <c> /command/s6-svc -d /run/service/gateway-<name>   # down

# Watch reconciler log
docker exec <c> tail -n 50 /opt/data/logs/container-boot.log
```

## Common Pitfalls

1. **"command not found" via docker exec** — `/command/` not on PATH; use absolute `/command/s6-svstat`
2. **Profile directory ownership** — stage2-hook.sh chowns profiles on every boot; don't remove that block
3. **Files written by docker exec are root-owned** — pass `--user hermes` or rely on next reboot chown
4. **Service slot exists but "s6-supervise not running"** — tmpfs wiped on restart; give cont-init.d a moment
5. **Gateway starts then immediately exits** — profile has no model/auth configured; run `hermes -p <profile> setup`
6. **Reconciler skipped a profile** — missing SOUL.md; add one to opt back in
7. **Container exits 143** — something invoked halt/s6-svscanctl -t; let CMD exit normally
