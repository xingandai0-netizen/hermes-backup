# Fact Store Management Reference

## Data Architecture

Hermes has three independent data stores:

| Database | Path | Content | Usage |
|----------|------|---------|-------|
| memory_store.db | ~/.hermes/memory_store.db | fact_store structured facts | fact_store() tool |
| memories.db | ~/.hermes/memory/memories.db | Old memory system (may be empty/deprecated) | - |
| state.db | ~/.hermes/state.db | sessions, messages, state_meta | session_search() |

**Key discovery:** user.md and memory.md are NOT independent files. Memory data is injected via system_prompt at session start, stored in state.db sessions.system_prompt field.

## Initialization/Rebuild

### Step 1: Verify current state
```sql
sqlite3 ~/.hermes/memory_store.db "SELECT COUNT(*) FROM facts;"
sqlite3 ~/.hermes/state.db "SELECT COUNT(*) FROM sessions;"
```

### Step 2: Extract source data from state.db
```bash
# Get latest session ID
sqlite3 ~/.hermes/state.db "SELECT id FROM sessions ORDER BY started_at DESC LIMIT 1;"
# Extract system_prompt, then grep for MEMORY and USER PROFILE sections
```

### Step 3: Classify facts into categories
- **project** (17 typical): deployment, channels, lessons learned
- **user_pref** (12 typical): communication style, execution rules
- **tool** (7 typical): environment info, Hermes config, security rules

### Step 4: Batch write with fact_store(action='add')
Multiple add calls can run in parallel (tools support independent requests simultaneously).

### Step 5: Verify with probe, reason, search

## Schema

```sql
facts (fact_id, content, category, tags, trust_score, retrieval_count, helpful_count, created_at, updated_at, hrr_vector)
entities (entity_id, name, entity_type, aliases, created_at)
fact_entities (fact_id, entity_id)  -- many-to-many
memory_banks (bank_id, bank_name, vector, dim, fact_count, updated_at)
facts_fts  -- FTS5 virtual table, auto-synced via triggers
```

## Daily Operations

```python
fact_store(action='add', category='project', content='...', tags='tag1,tag2')
fact_store(action='search', query='keyword')
fact_store(action='probe', entity='entity_name')
fact_store(action='reason', entities=['entity1', 'entity2'])
fact_feedback(action='helpful', fact_id=5)
```

## Known Pitfalls

1. `fact_store list` defaults to 10 items — use sqlite COUNT(*) for totals
2. `fact_id` auto-increments from 1 — deleted IDs not reused
3. `trust_score` starts at 0.4 — needs fact_feedback to train
4. `content` field UNIQUE — can't add duplicate content
5. memory/memories.db and memory_store.db are independent systems
6. system_prompt is 25KB+ — use grep/sed for precise extraction
7. Batch writes: one fact per call, but parallel calls work
8. Always verify with probe + reason + search after initialization
