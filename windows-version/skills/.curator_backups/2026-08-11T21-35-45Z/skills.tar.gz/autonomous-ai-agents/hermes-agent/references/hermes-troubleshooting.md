# Hermes Troubleshooting Reference

## Diagnostic Sequence (Ordered)

Always follow this order — earlier issues cause downstream failures.

### Step 1: Read Error Logs

```bash
# Most recent errors (first place to look)
read_file ~/.hermes/logs/errors.log (last 100 lines)
# Gateway-specific errors
read_file ~/.hermes/logs/gateway.log (last 50 lines)
```

### Common Error Patterns

| Error Pattern | Root Cause | Fix |
|---|---|---|
| `no such table: tasks` | kanban.db corrupted or missing schema | `hermes kanban init` |
| `mapping values are not allowed here` | YAML config syntax error | Fix config.yaml |
| `HTTP 401: Invalid API Key` | Config not loaded or key wrong | Check config parse + .env |
| `HTTP 401: Missing Authentication header` | Provider configured but no key | Run `hermes auth` |
| `Resource temporarily unavailable (os error 35)` | cua-driver process stuck | Restart cua-driver |
| `Connection error` + retries | API endpoint unreachable | Check network |
| `Failed to parse config.yaml` | YAML syntax error — config fallback to defaults | **CRITICAL: fix immediately** |

### Step 2: Check Config Integrity

```bash
python3 -c "import yaml; yaml.safe_load(open('$HOME/.hermes/config.yaml')); print('OK')"
```

### Failure Chain Pattern

```
Config YAML syntax error
  → Config fallback to defaults
    → API keys not loaded
      → 401 authentication errors
        → Agent can't respond
          → User sees crash/freeze
```

**Always fix upstream first.**

### Key Log Files

| File | Contents |
|---|---|
| `~/.hermes/logs/errors.log` | All ERROR/WARNING entries |
| `~/.hermes/logs/gateway.log` | Gateway-specific output |
| `~/.hermes/logs/agent.log` | Agent conversation loop |
| `~/.hermes/interrupt_debug.log` | User interrupt events |

## Terminal Blocked by Security Scan (Cron Jobs)

When ALL `terminal` calls return `pending_approval` with `status: "pending_approval"` and `description: "Security scan: security issue detected"`, the tirith security scanner is blocking command execution in cron mode.

**Root cause:** The cron profile's `approvals.cron_mode` setting is too restrictive.

**Workaround:** Use `read_file`, `search_files`, `write_file` for file-based diagnostics.

**Fix:** Set `approvals.cron_mode: approve` or add specific script paths to the allowlist.

## execute_code Failures in Cron Jobs

When `execute_code` fails with `FileNotFoundError` even for trivial code, the Python venv binary is missing or broken in the cron execution context.

**Known pattern:** Cron jobs using certain models consistently fail to execute Python scripts. `delegate_task` with `terminal` toolset may only receive `process` tool (not `terminal`).

**Resolution:** Verify Python environment for non-interactive execution. Run `hermes doctor`.
