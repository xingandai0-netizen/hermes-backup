# Hermes GitHub Backup Reference

## What to Back Up

| Keep | Exclude | Why |
|------|---------|-----|
| `skills/` | `hermes-agent/` | Codebase — recloneable |
| `sessions/` | `node/` | node_modules |
| `memory/` | `checkpoints/` | Transient |
| `config.yaml` | `cache/`, `logs/` | Transient |
| `scripts/` | `bin/` | Binaries |
| `cron/` | `*.db`, `*.db-wal` | SQLite 300MB+ blobs |
| `session-archives/` | `.env` | Secrets |
| `daily-logs/` | `audio_cache/`, `pastes/` | Transient |

## Backup Script

Create `~/.hermes/scripts/hermes-backup.sh` — uses rsync + git push. Key features:
- Clones or updates backup repo
- Rsyncs only valuable data (excludes .env, .backup-repo, .git, hermes-agent/, node/, etc.)
- Commits and pushes incrementally
- No LLM needed (`no_agent: true` cronjob)

## Cronjob Setup

```bash
# Via cronjob tool:
name: "Hermes Daily Backup"
schedule: "0 3 * * *"
script: "hermes-backup.sh"  # Relative to ~/.hermes/scripts/
no_agent: true
deliver: "local"
```

## Cross-Agent Backup Architecture

Each AI agent gets its OWN separate backup repo:

| Agent | Repo | Contents |
|-------|------|----------|
| 小黑 (Hermes) | `hermes-backup` | Hermes config, skills, memories, SOUL.md |
| 小黄 (Claude CLI) | separate repo | CLAUDE.md, memory files, skills reference |

## Key Pitfalls

1. **state.db is enormous** (500MB+) — exclude it; sessions JSON suffices
2. **Git token-as-password deprecated** — use `gh auth login --with-token`
3. **Cronjob script path MUST be relative** — just filename, not absolute path
4. **First push may timeout** — exclude large dirs, push manually first
5. **Private repos need auth** — `raw.githubusercontent.com` returns 404 for private repos
6. **Classic vs Fine-grained tokens** — classic (`ghp_`) for full automation; fine-grained (`github_pat_`) can't create repos
7. **`gh auth setup-git`** — needed after `gh auth login` for git credential helper
8. **User preference: explain before acting** — describe changes before executing
9. **Windows PowerShell** — no `&&` (use `;`), no `~` (use `$HOME`), no `curl` (use `Invoke-WebRequest`)
10. **Claude CLI refuses self-deployment** — user must manually deploy config files
