# CC Switch Configuration Reference

> Absorbed from `cc-switch-configuration` skill (archived 2026-06-21).

## Overview
CC Switch (v3.14.1+) is an AI coding tool proxy manager. It intercepts CLI tool API requests via local proxy (127.0.0.1:15721) and routes them to custom API providers.

⚠️ **CC Switch proxy only works for CLI tools** (Claude Code, Codex, Gemini CLI). Claude Desktop GUI uses OAuth + hardcoded endpoints and cannot be proxied.

## Data Storage
- `~/.cc-switch/cc-switch.db` — SQLite main database
- `~/.cc-switch/settings.json` — Global settings
- `~/.cc-switch/logs/cc-switch.log` — Runtime logs

## Key Database Tables
- `providers` — API provider configs (app_type, settings_config JSON, is_current)
- `proxy_config` — Per-client proxy toggles (enabled, proxy_enabled, live_takeover_active)
- `proxy_request_logs` — API request logs (model, cost, latency, status)
- `proxy_live_backup` — Pre-takeover config backups

## Enable Claude Proxy (3 steps)

```bash
# 1. Confirm provider exists and is selected
sqlite3 ~/.cc-switch/cc-switch.db "SELECT id, name, is_current FROM providers WHERE app_type='claude';"

# 2. Enable proxy
sed -i '' 's/"enableLocalProxy": false/"enableLocalProxy": true/' ~/.cc-switch/settings.json
sqlite3 ~/.cc-switch/cc-switch.db "UPDATE proxy_config SET enabled=1, proxy_enabled=1, live_takeover_active=1 WHERE app_type='claude';"

# 3. Restart CC Switch
kill $(pgrep cc-switch) && sleep 2 && open "/Applications/CC Switch.app" && sleep 4
```

## Verify Proxy Works
```bash
# Step A: Port listening
lsof -p $(pgrep cc-switch) -i -P 2>/dev/null | grep 15721

# Step B: Check request logs (MUST be > 0)
sqlite3 ~/.cc-switch/cc-switch.db "SELECT COUNT(*) FROM proxy_request_logs WHERE app_type='claude';"
```

## Critical Pitfalls
1. Provider configured ≠ proxy enabled — must set BOTH `settings.json` enableLocalProxy AND proxy_config enabled
2. CC Switch logs saying "taken over" doesn't mean traffic flows through proxy — verify proxy_request_logs count
3. Claude Desktop GUI CANNOT be proxied (OAuth + hardcoded endpoints)
4. Restart CC Switch after changing proxy_config
