---
name: vercel-railway-cloudflare-deploy
description: "Vercel + Railway + Cloudflare 完整部署指南：前端部署、后端部署、DNS配置、SSL模式、环境变量、常见陷阱。合并了 vercel-cloudflare-deployment 和 vercel-railway-deployment。"
version: 1.0
tags: [deployment, vercel, railway, cloudflare, nextjs, fastapi, dns]
---

# Vercel + Railway + Cloudflare 部署方案

## 架构

```
用户 → Cloudflare (DNS/CDN) → Vercel (Next.js 前端)
                                    ↓
                              FastAPI 后端 (Railway)
```

## 何时使用

- Next.js 前端 + FastAPI 后端项目
- 需要自定义域名
- 不想管理服务器

## 关键步骤

### 1. GitHub 推送

```bash
cd ~/project
git add -A && git commit -m "deploy"
# 如果 gh auth 失败，直接用 token
git remote set-url origin https://USERNAME:TOKEN@github.com/USER/REPO.git
git push origin main
```

**坑点**：`gh auth login` 经常失败。直接用 token 在 remote URL 更可靠。

### 2. Vercel 部署前端

```bash
# CLI 安装（注意路径）
npm install -g vercel
# CLI 在 ~/.hermes/node/bin/vercel，不在 PATH

# 登录（需要浏览器授权）
~/.hermes/node/bin/vercel login --github

# 部署
cd frontend
~/.hermes/node/bin/vercel --prod --yes

# 添加环境变量
~/.hermes/node/bin/vercel link --yes
echo "VALUE" | ~/.hermes/node/bin/vercel env add KEY production

# 添加域名
~/.hermes/node/bin/vercel domains add example.com
```

**坑点**：
- Vercel CLI 安装在 `~/.hermes/node/bin/`，不在 PATH
- `vercel login` 需要浏览器授权，超时 60s
- `NEXT_PUBLIC_` 变量需要重新部署才生效
- 添加域名后需要配置 DNS（A 记录指向 76.76.21.21）

### 3. Railway 部署后端

```bash
# 安装 CLI
npm install -g @railway/cli

# 登录
~/.hermes/node/bin/railway login

# 创建项目
cd backend
~/.hermes/node/bin/railway init --name PROJECT_NAME

# 部署
~/.hermes/node/bin/railway up --service SERVICE_NAME --detach

# 获取域名
~/.hermes/node/bin/railway domain
```

**坑点**：
- Python 项目需要 `Procfile` 或 `Dockerfile`
- Railway 默认 Python 3.13，pydantic-core 不兼容
- 解决：创建 `runtime.txt` 指定 `python-3.11.9`
- 或用 Dockerfile 指定 `FROM python:3.11-slim`

### 4. Cloudflare DNS 配置

```bash
# API Token 需要 Zone:DNS:Edit 权限
# 先检查域名是否在账号中
curl -s "https://api.cloudflare.com/client/v4/zones?name=DOMAIN" \
  -H "Authorization: Bearer TOKEN"

# 添加 A 记录
curl -s -X POST "https://api.cloudflare.com/client/v4/zones/ZONE_ID/dns_records" \
  -H "Authorization: Bearer TOKEN" \
  -H "Content-Type: application/json" \
  --data '{"type":"A","name":"@","content":"76.76.21.21","ttl":1,"proxied":true}'
```

**坑点**：
- API Token 必须是 `cfat_` 开头（不是 `ghp_`）
- 域名必须先添加到 Cloudflare 账号才能用 API 管理
- Vercel 的 A 记录 IP 是 `76.76.21.21`
- 需要等 DNS 传播（最多 24 小时）

## FastAPI 后端配置

### Procfile
```
web: uvicorn app.main:app --host 0.0.0.0 --port $PORT
```

### Dockerfile（推荐）
```dockerfile
FROM python:3.11-slim
WORKDIR /app
RUN apt-get update && apt-get install -y ffmpeg && rm -rf /var/lib/apt/lists/*
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
EXPOSE 8000
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

### runtime.txt
```
python-3.11.9
```

### CORS 配置
```python
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://your-domain.com"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

## 前端 API 地址配置

```typescript
// src/lib/api.ts
export function getApiBase(): string {
  if (process.env.NEXT_PUBLIC_API_URL) {
    return process.env.NEXT_PUBLIC_API_URL;
  }
  if (typeof window !== 'undefined') {
    const { protocol, hostname } = window.location;
    if (hostname === 'your-domain.com') {
      return process.env.NEXT_PUBLIC_API_URL || '';
    }
    return `${protocol}//${hostname}:8000`;
  }
  return process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';
}
```

## 验证清单

- [ ] GitHub 推送成功
- [ ] Vercel 构建成功（检查 build log）
- [ ] Railway 构建成功（检查 logs）
- [ ] 环境变量已设置（NEXT_PUBLIC_API_URL）
- [ ] 前端 URL 可访问
- [ ] 后端 URL 可访问（/docs）
- [ ] DNS A 记录已添加
- [ ] 自定义域名可访问
- [ ] API 调用正常（前端→后端）

## SSL 模式说明

| Mode | Behavior | Use Case |
|------|----------|----------|
| Flexible | CF → HTTP → Origin | ❌ 和 Vercel 一起用会导致重定向循环 |
| **Full** | CF → HTTPS → Origin | ✅ 推荐 |
| Full (Strict) | CF → HTTPS → Valid Cert | ✅ 原站有有效证书时 |

## 部署验证

```bash
# DNS 解析检查
nslookup antokex.com

# Vercel 部署检查
vercel ls

# Railway 状态
railway status

# API 测试
curl https://backend.railway.app/docs

# 前端→后端通信
curl -s https://your-domain.com/api/health
```

## 成本

- Vercel: 免费额度足够个人项目
- Railway: 免费 $5/月 credit
- Cloudflare: 免费计划
- 总计: $0/月（免费额度内）
